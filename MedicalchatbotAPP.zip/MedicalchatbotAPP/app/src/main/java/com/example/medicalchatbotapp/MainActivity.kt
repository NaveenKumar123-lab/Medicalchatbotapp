package com.example.medicalchatbotapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

data class Doctor(
    val name: String,
    val hospitalName: String,
    val hospitalLocation: String,
    val appointmentDate: String
)

class MainActivity : AppCompatActivity() {
    private lateinit var chatTextView: TextView
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button
    private lateinit var viewHospitalsButton: Button
    private lateinit var viewDoctorsButton: Button
    private lateinit var viewLocationsButton: Button
    private lateinit var timeSlotSpinner: Spinner
    private lateinit var locationSpinner: Spinner
    private lateinit var hospitalSpinner: Spinner
    private lateinit var doctorSpinner: Spinner
    private lateinit var clearChatButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        chatTextView = findViewById(R.id.chatTextView)
        messageEditText = findViewById(R.id.messageEditText)
        sendButton = findViewById(R.id.sendButton)
        viewHospitalsButton = findViewById(R.id.viewHospitalsButton)
        viewDoctorsButton = findViewById(R.id.viewDoctorsButton)
        viewLocationsButton = findViewById(R.id.viewLocationsButton)
        timeSlotSpinner = findViewById(R.id.timeSlotSpinner)
        locationSpinner = findViewById(R.id.locationSpinner)
        hospitalSpinner = findViewById(R.id.hospitalSpinner)
        doctorSpinner = findViewById(R.id.doctorSpinner)
        clearChatButton = findViewById(R.id.clearChatButton)

        sendButton.setOnClickListener {
            val message = messageEditText.text.toString()
            if (message.isNotEmpty()) {
                appendMessage("Patient: $message")
                when {
                    message.equals("available locations", ignoreCase = true) -> displayAvailableLocations()
                    message.equals("book appointment", ignoreCase = true) -> bookAppointment()
                    else -> {
                        val reply = getDoctorReply(message)
                        appendMessage("Doctor: $reply")
                    }
                }
                messageEditText.text.clear()
            }
        }

        viewHospitalsButton.setOnClickListener {
            displayHospitals()
        }

        viewDoctorsButton.setOnClickListener {
            displayDoctors()
        }

        viewLocationsButton.setOnClickListener {
            displayLocations()
        }

        clearChatButton.setOnClickListener {
            clearChat()
        }

        // Populate the spinners with available options
        val timeSlots = getAppointmentTimeSlots()
        val timeSlotAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, timeSlots)
        timeSlotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        timeSlotSpinner.adapter = timeSlotAdapter

        val availableLocations = getAvailableLocations()
        val locationAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, availableLocations)
        locationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        locationSpinner.adapter = locationAdapter

        val hospitals = availableLocations.map { (_, hospitalName) -> hospitalName }
        val hospitalAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, hospitals)
        hospitalAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        hospitalSpinner.adapter = hospitalAdapter

        val doctors = availableLocations.flatMap { (location, hospitalName) ->
            val doctor = getDoctorDetails("Acetaminophen") // Use a default prescription for simplicity
            listOf("${doctor.name} - $hospitalName ($location)")
        }
        val doctorAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, doctors)
        doctorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        doctorSpinner.adapter = doctorAdapter
    }

    private fun appendMessage(message: String) {
        chatTextView.append("$message\n")
    }

    private fun clearChat() {
        chatTextView.text = ""
    }

    private fun displayAvailableLocations() {
        val availableLocations = getAvailableLocations()
        val locationsText = availableLocations.joinToString("\n") { (location, hospitalName) ->
            "$hospitalName - $location"
        }
        appendMessage("Doctor: Available locations:\n$locationsText")
    }

    private fun bookAppointment() {
        val selectedTimeSlot = timeSlotSpinner.selectedItem.toString()
        val selectedLocation = locationSpinner.selectedItem.toString()
        val selectedHospital = hospitalSpinner.selectedItem.toString()
        val selectedDoctor = doctorSpinner.selectedItem.toString()

        appendMessage("Doctor: You have successfully booked an appointment with $selectedDoctor")
        appendMessage("Doctor: Hospital: $selectedHospital")
        appendMessage("Doctor: Location: $selectedLocation")
        appendMessage("Doctor: Appointment Date: ${getAppointmentDate(selectedDoctor)}")
        appendMessage("Doctor: Selected Time Slot: $selectedTimeSlot")
    }

    private fun getAvailableLocations(): List<Pair<String, String>> {
        return listOf(
            "Bangalore, India" to "Rainbow Hospital",
            "Bangalore, India" to "Manipal Hospital",
            "Bangalore, India" to "SON JOHNS Hospital",
            "Bangalore, India" to "GHI Hospital"
        )
    }

    private fun getDoctorReply(message: String): String {
        val prescription = getPrescription(message)
        val doctor = getDoctorDetails(prescription)

        return "Prescription: $prescription\nDoctor's Name: ${doctor.name}\nHospital Name: ${doctor.hospitalName}\nHospital Location: ${doctor.hospitalLocation}\nAppointment Date: ${getAppointmentDate(doctor.name)}"
    }

    private fun getPrescription(message: String): String {
        return when {
            message.contains("headache", ignoreCase = true) -> "Acetaminophen"
            message.contains("cough", ignoreCase = true) -> "Cough Syrup"
            message.contains("fever", ignoreCase = true) -> "Ibuprofen"
            else -> "Please consult a doctor for proper diagnosis and medication."
        }
    }

    private fun getDoctorDetails(prescription: String): Doctor {
        val availableLocations = getAvailableLocations()
        val (location, hospitalName) = availableLocations.random()
        val doctor = when (prescription) {
            "Acetaminophen" -> Doctor("Dr. John Doe", hospitalName, location, "July 10, 2023")
            "Cough Syrup" -> Doctor("Dr. Jane Smith", hospitalName, location, "July 15, 2023")
            "Ibuprofen" -> Doctor("Dr. Michael Johnson", hospitalName, location, "July 20, 2023")
            else -> Doctor("Dr. Robert Wilson", hospitalName, location, "July 25, 2023")
        }
        return doctor
    }

    private fun getAppointmentTimeSlots(): List<String> {
        return listOf("9:00 AM", "11:00 AM", "2:30 PM", "4:00 PM").shuffled()
    }

    private fun getAppointmentDate(doctorName: String): String {
        val availableLocations = getAvailableLocations()
        val (_, hospitalName) = availableLocations.random()
        return when (doctorName) {
            "Dr. John Doe" -> "July 10, 2023"
            "Dr. Jane Smith" -> "July 15, 2023"
            "Dr. Michael Johnson" -> "July 20, 2023"
            else -> "July 25, 2023"
        }
    }

    private fun displayHospitals() {
        val availableLocations = getAvailableLocations()
        val hospitals = availableLocations.map { (_, hospitalName) -> hospitalName }
        val hospitalsText = hospitals.joinToString("\n")
        appendMessage("Doctor: Available hospitals:\n$hospitalsText")
    }

    private fun displayDoctors() {
        val availableLocations = getAvailableLocations()
        val doctors = availableLocations.flatMap { (location, hospitalName) ->
            val doctor = getDoctorDetails("Acetaminophen") // Use a default prescription for simplicity
            listOf("${doctor.name} - $hospitalName ($location)")
        }
        val doctorsText = doctors.joinToString("\n")
        appendMessage("Doctor: Available doctors:\n$doctorsText")
    }

    private fun displayLocations() {
        val availableLocations = getAvailableLocations()
        val locations = availableLocations.map { (location, hospitalName) ->
            "$hospitalName - $location"
        }
        val locationsText = locations.joinToString("\n")
        appendMessage("Doctor: Available locations:\n$locationsText")
    }
}